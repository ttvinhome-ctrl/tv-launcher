package id.launcher.tv

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

// GANTI dengan koordinat kotamu (dipakai untuk cuaca dan waktu sholat)
const val LAT = -6.2088
const val LON = 106.8456

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class AppItem(val pkg: String, val label: String, val icon: Drawable, val intent: Intent)

class Wall(c: android.content.Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        cv.drawColor(0xFF1A1033.toInt())
        fun blob(x: Float, y: Float, r: Float, col: Int) {
            p.shader = RadialGradient(x, y, r, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, p)
        }
        blob(w * .12f, h * .08f, w * .6f, 0xFFFF6A88.toInt())
        blob(w * .92f, h * .18f, w * .55f, 0xFF5B6CFF.toInt())
        blob(w * .72f, h * 1.05f, w * .65f, 0xFFFF9A4D.toInt())
        blob(0f, h, w * .55f, 0xFF7A3CFF.toInt())
        p.shader = null
        p.color = 0x66080618
        cv.drawRect(0f, 0f, w, h, p)
    }
}

fun glass(r: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x4DFFFFFF, 0x14FFFFFF)).apply {
        cornerRadius = r.toFloat()
        setStroke(2, 0x55FFFFFF)
    }

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private lateinit var scroll: ScrollView
    private lateinit var p2: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var clockT: TextView
    private lateinit var dateT: TextView
    private lateinit var wifiT: TextView
    private lateinit var weatherT: TextView
    private lateinit var prayerT: TextView
    private lateinit var lastT: TextView
    private lateinit var lastW: View
    private var apps = listOf<AppItem>()
    private var times = mapOf<String, String>()
    private var pDay = ""
    private var wxAt = 0L
    private var H = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun txt(s: String, sp: Float, bold: Boolean = false, col: Int = Color.WHITE) = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(col)
        typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun fx(v: View) {
        v.setOnFocusChangeListener { x, f ->
            val s = if (f) 1.1f else 1f
            x.animate().scaleX(s).scaleY(s).setDuration(150).start()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        H = resources.displayMetrics.heightPixels
        val root = FrameLayout(this)
        root.addView(Wall(this), FrameLayout.LayoutParams(MATCH, MATCH))
        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        content.addView(buildHome(), LinearLayout.LayoutParams(MATCH, H))
        content.addView(buildApps(), LinearLayout.LayoutParams(MATCH, WRAP))
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    private fun widget(label: String): Pair<LinearLayout, TextView> {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(dp(24))
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        l.addView(txt(label.uppercase(), 10f, col = 0xD9FFFFFF.toInt()))
        val v = txt("...", 18f, true)
        l.addView(v)
        return Pair(l, v)
    }

    private fun buildHome(): FrameLayout {
        val p = FrameLayout(this).apply { clipChildren = false }
        wifiT = txt("Wi-Fi", 13f).apply { setPadding(dp(16), dp(9), dp(16), dp(9)); background = glass(dp(20)) }
        p.addView(wifiT, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { setMargins(dp(44), dp(28), 0, 0) })
        val gear = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_manage)
            setColorFilter(Color.WHITE)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = glass(dp(23))
            isFocusable = true
            isClickable = true
            setOnClickListener { quick() }
        }
        fx(gear)
        p.addView(gear, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(24), dp(44), 0) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false }
        dateT = txt("", 20f)
        clockT = txt("", 112f, true).apply { includeFontPadding = false; letterSpacing = -0.04f }
        col.addView(dateT)
        col.addView(clockT)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; clipChildren = false }
        val w1 = widget("Cuaca")
        val w2 = widget("Sholat berikutnya")
        val w3 = widget("Lanjutkan")
        weatherT = w1.second
        prayerT = w2.second
        lastT = w3.second
        lastW = w3.first
        lastW.isFocusable = true
        lastW.isClickable = true
        fx(lastW)
        for (w in listOf(w1, w2, w3)) row.addView(w.first, LinearLayout.LayoutParams(dp(200), dp(78)).apply { setMargins(dp(7), 0, dp(7), 0) })
        col.addView(row, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(18) })
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; clipChildren = false; clipToPadding = false }
        col.addView(dock, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(36) })
        p.addView(col, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { topMargin = dp(60) })
        return p
    }

    private fun buildApps(): LinearLayout {
        p2 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            minimumHeight = H
            setPadding(dp(56), dp(48), dp(56), dp(48))
            clipChildren = false
        }
        p2.addView(txt("Semua Aplikasi", 30f, true))
        grid = GridLayout(this).apply { columnCount = 6; clipChildren = false }
        p2.addView(grid, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(28) })
        return p2
    }

    private fun loadApps() {
        val pm = packageManager
        val out = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (r in pm.queryIntentActivities(q, 0)) {
                val ai = r.activityInfo
                if (ai.packageName == packageName || out.containsKey(ai.packageName)) continue
                val go = Intent(Intent.ACTION_MAIN).addCategory(cat).setClassName(ai.packageName, ai.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                out[ai.packageName] = AppItem(ai.packageName, r.loadLabel(pm).toString(), r.loadIcon(pm), go)
            }
        }
        apps = out.values.sortedBy { it.label.lowercase() }
    }

    private fun dockApps(): List<AppItem> {
        val fav = listOf("com.google.android.youtube.tv", "com.spotify.tv.android", "com.netflix.ninja", "com.iqiyi.i18n.tv", "com.android.vending")
        return apps.sortedWith(
            compareBy<AppItem>(
                { -prefs.getInt("n_" + it.pkg, 0) },
                { fav.indexOf(it.pkg).let { i -> if (i < 0) 99 else i } },
                { it.label }
            )
        ).take(6)
    }

    private fun open(a: AppItem) {
        prefs.edit().putInt("n_" + a.pkg, prefs.getInt("n_" + a.pkg, 0) + 1).putString("last", a.pkg).apply()
        try {
            startActivity(a.intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka " + a.label, Toast.LENGTH_SHORT).show()
        }
    }

    private fun cell(a: AppItem, always: Boolean, isDock: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true
            isClickable = true
            clipChildren = false
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }
        val img = ImageView(this).apply {
            setImageDrawable(a.icon.constantState?.newDrawable()?.mutate() ?: a.icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, v.width * 0.22f)
                }
            }
        }
        box.addView(img, LinearLayout.LayoutParams(dp(88), dp(88)))
        val lab = txt(a.label, 13f).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            alpha = if (always) 1f else 0f
        }
        box.addView(lab, LinearLayout.LayoutParams(dp(104), WRAP).apply { topMargin = dp(8) })
        box.setOnClickListener { open(a) }
        box.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.15f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(150).start()
            v.translationZ = if (f) dp(12).toFloat() else 0f
            if (!always) lab.animate().alpha(if (f) 1f else 0f).setDuration(150).start()
            if (f) scroll.smoothScrollTo(0, if (isDock) 0 else maxOf(0, p2.top + grid.top + v.top - dp(110)))
        }
        return box
    }

    private fun quick() {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable().apply { setColor(0xE62A1F4D.toInt()); cornerRadius = dp(28).toFloat(); setStroke(2, 0x55FFFFFF) }
        }
        box.addView(txt("Pengaturan Cepat", 18f, true))
        val items = listOf(
            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
            "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Layar" to Settings.ACTION_DISPLAY_SETTINGS,
            "Suara" to Settings.ACTION_SOUND_SETTINGS,
            "Semua Pengaturan" to Settings.ACTION_SETTINGS
        )
        for ((n, act) in items) {
            val bt = txt(n, 16f).apply {
                setPadding(dp(18), dp(14), dp(18), dp(14))
                background = glass(dp(18))
                isFocusable = true
                isClickable = true
                setOnClickListener {
                    dlg.dismiss()
                    try {
                        startActivity(Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) {}
                    }
                }
            }
            fx(bt)
            box.addView(bt, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        dlg.setContentView(box)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.END or Gravity.CENTER_VERTICAL)
            setLayout(dp(340), WRAP)
        }
        dlg.show()
        box.getChildAt(1)?.requestFocus()
    }

    private fun wifi() {
        val s = try {
            (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).connectionInfo.ssid.trim('"')
        } catch (e: Exception) { "" }
        wifiT.text = if (s.isBlank() || s == "<unknown ssid>") "Wi-Fi" else s
    }

    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun fetchWeather() = thread {
        try {
            val j = JSONObject(http("https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code&timezone=auto")).getJSONObject("current")
            val t = Math.round(j.getDouble("temperature_2m"))
            val d = when (j.getInt("weather_code")) {
                0 -> "Cerah"
                1, 2 -> "Cerah berawan"
                3 -> "Berawan"
                45, 48 -> "Berkabut"
                in 51..67 -> "Hujan"
                in 80..82 -> "Hujan lebat"
                95, 96, 99 -> "Badai petir"
                else -> ""
            }
            ui.post { weatherT.text = "$t° $d" }
        } catch (e: Exception) {}
    }

    private fun fetchPrayer(day: String) = thread {
        try {
            val t = JSONObject(http("https://api.aladhan.com/v1/timings/$day?latitude=$LAT&longitude=$LON&method=20"))
                .getJSONObject("data").getJSONObject("timings")
            val m = LinkedHashMap<String, String>()
            for ((k, n) in listOf("Fajr" to "Subuh", "Dhuhr" to "Dzuhur", "Asr" to "Ashar", "Maghrib" to "Maghrib", "Isha" to "Isya")) {
                m[n] = t.getString(k).take(5)
            }
            times = m
            ui.post { updatePrayer() }
        } catch (e: Exception) {}
    }

    private fun updatePrayer() {
        if (times.isEmpty()) return
        val now = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        val nx = times.entries.firstOrNull { it.value > now } ?: times.entries.first()
        prayerT.text = nx.value + " " + nx.key
    }

    private val tick = object : Runnable {
        override fun run() {
            val n = Date()
            clockT.text = SimpleDateFormat("HH:mm", Locale.US).format(n)
            dateT.text = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(n)
            val day = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(n)
            if (pDay != day) { pDay = day; fetchPrayer(day) }
            if (System.currentTimeMillis() - wxAt > 1_800_000L) { wxAt = System.currentTimeMillis(); fetchWeather() }
            updatePrayer()
            ui.postDelayed(this, 10_000)
        }
    }

    private fun showLast() {
        val p = prefs.getString("last", null)
        val a = apps.firstOrNull { it.pkg == p }
        lastT.text = a?.label ?: "-"
        lastW.setOnClickListener { a?.let { open(it) } }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        dock.removeAllViews()
        for (a in dockApps()) dock.addView(cell(a, false, true))
        grid.removeAllViews()
        for (a in apps) grid.addView(cell(a, true, false))
        wifi()
        pDay = ""
        wxAt = 0L
        ui.post(tick)
        showLast()
        dock.getChildAt(0)?.requestFocus()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    override fun onBackPressed() {
        scroll.smoothScrollTo(0, 0)
        dock.getChildAt(0)?.requestFocus()
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        onBackPressed()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        wifi()
    }
}
